from django.shortcuts import render
from .models import *
# Create your views here.

def InsertPageView(request):
    return render(request,"app/insert.html")


def InsertData(request):
    # Data come from HTML to View
    fname = request.POST['fname']
    lname = request.POST['lname']
    email = request.POST['email']
    contact = request.POST['contact']

    # Creating Object of Model Class
    # Inserting Data into Table
    newuser = Student.objects.create(Firstname=fname,Lastname=lname,    
                                        Email=email,Contact=contact)

    # After Insert render on Show.html
    return render(request,"app/show.html")